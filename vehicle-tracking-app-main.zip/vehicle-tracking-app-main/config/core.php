<?php

return [
    'image' => [
        'default' => [
        	'logo2d' => '/assets/uploads/default/logo-2d.png',
        	'logo3d' => '/assets/uploads/default/logo-3d.jpg',
        	'logoadmin' => '/assets/uploads/default/logo-admin.png',
            'avatar' => '/assets/uploads/default/avatar.jpg',
            'cover'  => '/assets/uploads/default/cover.png',
        ]
    ],
];
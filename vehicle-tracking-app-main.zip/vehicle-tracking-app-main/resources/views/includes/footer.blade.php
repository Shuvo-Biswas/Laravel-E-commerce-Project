<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <script>document.write(new Date().getFullYear())</script> © {{ config('app.name') }}.
                    Developed by <a href="">Snigdho</a>
            </div>
        </div>
    </div>
</footer>